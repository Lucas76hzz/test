def to_json(self):
    return {'name': self.name, 'strat': self.strat}
